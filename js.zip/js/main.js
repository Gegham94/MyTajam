// Slider Content
var count=0, sliderAmount=4;
var sliderContent = '';
SliderContentCreate();
setThePositionOfSlider();
function SliderContentCreate(){
    for(var i=0; i<sliderAmount; i++){
        sliderContent +=
            `<div class='general bgdiv`+i+`'>
            <div class="TitleContent">We Are Awesome Creative Agency</div>
            <br/>
            <div class="SliderUnderline"></div>
            <br/>
            <div class="TextContent">This is Photoshop's version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem
            <br/>
                quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh
                <br/>
                vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit`+i+`.
            </div>
            <br/>
            <br/>
            <div class="Button">LEARN MORE</div>
        </div>`;
    }
    for(var j = 0; j< 4; j++){
        j==0?sliderContent+='<div class="dotsContent">':'';
        sliderContent+="<span class='dot' id = '"+j+"' onclick=bxSlider(this.id)></span>";
        j==3?sliderContent+="</div>":"";
    }
    document.getElementById("sliderContent").innerHTML = sliderContent;
}

// Slider Position function
function setThePositionOfSlider(){
    document.getElementsByClassName('dot')[0].style.backgroundColor = '#00DFCF';
    for(var i = 0; i<sliderAmount; i++){
        if(i<3){
            document.getElementsByClassName(`bgdiv`+i)[0].style.left= (i*100 +'%');
        }else{
            document.getElementsByClassName(`bgdiv`+i)[0].style.left= (-1*100 +'%');
        }
    }
}

// Box Slider function
function bxSlider(k){
    document.getElementsByClassName('dot')[0].style.backgroundColor = '';
    document.getElementsByClassName('dot')[count].style.backgroundColor = '';
    document.getElementsByClassName('dot')[k].style.backgroundColor = '#00DFCF';
    if(k>count){
       count++;
       changeThePositionaOfSliderStepsNext();
       let timerNext =  setInterval(()=>{
         if( k>count){
           count++;
           changeThePositionaOfSliderStepsNext();
           }
           else{
               clearInterval(timerNext);
           }
       }, 300)
   }
   else if(k<count){
       count--;
       changeThePositionaOfSliderStepsPreview();
       let timerNext =  setInterval(()=>{
           if( k<count){
             count--;
             changeThePositionaOfSliderStepsPreview();
           }
           else{
               clearInterval(timerNext);
           } 
       }, 300)
   }
}

// Next and Previews Of Spans functions
function changeThePositionaOfSliderStepsNext(){
    for(var i = 0; i<sliderAmount; i++){
        var left = document.getElementsByClassName(`bgdiv`+i)[0].style.left;
        if(left[0]=='0'){
            document.getElementsByClassName(`bgdiv`+i)[0].style.zIndex = '1';
            document.getElementsByClassName(`bgdiv`+i)[0].style.left = '-100%';
        }
        else if(left[0]>0 && left[0]< sliderAmount){
            document.getElementsByClassName(`bgdiv`+i)[0].style.zIndex = '1';
            document.getElementsByClassName(`bgdiv`+i)[0].style.left = (100 *(left[0]-1) +'%');
        }
        else if(left[0]=='-'){
            document.getElementsByClassName(`bgdiv`+i)[0].style.zIndex = '0';
            document.getElementsByClassName(`bgdiv`+i)[0].style.left = (sliderAmount-2)*100+'%';
        }
    }
}
function changeThePositionaOfSliderStepsPreview(){
    for(var i = 0; i<sliderAmount; i++){
        var left = document.getElementsByClassName(`bgdiv`+i)[0].style.left;
        if(left[0]=='0'){
            document.getElementsByClassName(`bgdiv`+i)[0].style.zIndex = '1';
            document.getElementsByClassName(`bgdiv`+i)[0].style.left = '100%';
        }
        else if(left[0]=='-'){
            document.getElementsByClassName(`bgdiv`+i)[0].style.zIndex = '1';
            document.getElementsByClassName(`bgdiv`+i)[0].style.left = '0%';
        }
        else if(left[0]=='1'){
            document.getElementsByClassName(`bgdiv`+i)[0].style.zIndex = '0';
            document.getElementsByClassName(`bgdiv`+i)[0].style.left = '200%';
        }
        else if(left[0]=='2'){
            document.getElementsByClassName(`bgdiv`+i)[0].style.zIndex = '0';
            document.getElementsByClassName(`bgdiv`+i)[0].style.left = '-100%';
        }
    }
}

// Video Content
var MyVideo = '';
function PlayerFu(){
    MyVideo = document.getElementById("VideoId");
    MyVideo.children[0].style.display = 'none';
    MyVideo.innerHTML = '<iframe class="IframeVideo" src="https://www.youtube.com/embed/Ukg_U3CnJWI?rel=0&autoplay=1" frameborder="0" allowfullscreen>';
}

